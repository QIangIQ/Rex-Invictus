Corporations that operate within the [[UOE]], or alongside it

| [[Akvavit Mercenary Liaison Organization]]                 |
| ---------------------------------------------------------- |
| [[Aldra Mercenary Liaison Organization]]                   |
| [[ARES technicha]]                                         |
| [[Arisawa Heavy Industries]]                               |
| [[Aspina Aggregates]]                                      |
| [[Astralnet Conglomerate]]                                 |
| [[Bernard & Felix Foundation]]                             |
| [[Blackstar Crucible]]                                     |
| [[Chem-Dyna]]                                              |
| [[Deadalus Reseach Evaluation & Developement Corporation]] |
| [[Durham Aerospace]]                                       |
| [[Everaude]]                                               |
| [[Evergreen Family]]                                       |
| [[Hawkes Prescison Instruments]]                           |
| [[Interior Union]]                                         |
| [[Leone-Mecchanica]]                                       |
| [[Melinite]]                                               |
| [[Mercenary Solutions and Advisory Corporation (MSAC)]]    |
| [[North Central Positronics]]                              |
| [[Proxima Point-Defence]]                                  |
| [[Rayleonard]]                                             |
| [[Rosenthal]]                                              |
| [[Scaperelli Knetics]]                                     |
| [[Serpentine Baylock]]                                     |
| [[Tian-Qiang Heavy Foundries]]                             |
| [[Aegis Technologies Syndicate]]                           |
| [[Beleth Mechanized Division]]                             |
| [[Deyang Foundries]]                                       |
| [[Elcano Ventures]]                                        |
| [[Helix Dynamics Group]]                                   |
| [[Horizon Engineering Corporation]]                        |
| [[Hadrian Harmonics]]                                      |
| [[Hadrian Ionics]]                                         |
| [[Hadrian Mechanized Legion]]                              |
| [[Hansen Mechanical Linguistics]]                          |
| [[Hadrian Tachyonics]]                                     |
| [[Institute Academy]]                                      |
| [[Nexus Systems Consortium]]                               |
| [[Tochter des Elysium R&D]]                                |
| [[Vanguard Armament Solutions]]                            |
| [[Vestal Fringe Corporation]]                              |
