Appears to be a Charity and Colonization Foundation. 
Instead actually specializes in money laundering and illegal material transportation