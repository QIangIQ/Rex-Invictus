
| Aepyornis        |
| ---------------- |
| Albierro         |
| Allbright        |
| Bornemizza       |
| Chaucher         |
| Dulabere         |
| Ekdromoi         |
| Euler            |
| Exfer            |
| Exsusia          |
| Expecet          |
| Feuerberg        |
| Fortaleza        |
| Gorenge          |
| Hawkins          |
| Hawkmoth         |
| Hayate           |
| Helianthus       |
| Hogire           |
| Kiritumi         |
| Klein Fake       |
| Lafayette        |
| Lancel           |
| Linstart         |
| Luciole          |
| Marien Kaefer    |
| Nachreiter       |
| Nashorn          |
| Nossac           |
| Papaggi          |
| Paphira          |
| Pater            |
| Predicator       |
| Remillee Fortmer |
| Rokkumonsen      |
| Sauterelle       |
| Scalopus         |
| Scarabaeus       |
| Sgarmotha        |
| Solarwind        |
| Tiger Moth       |
| Transcriber      |
| Verrill          |