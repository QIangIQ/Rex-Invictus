Part of the [[Greek Pantheon]]
Original owner: [[Zoe Nightshade]]
Previous owners:
[[Hercules]]
[[Chiron]]
Current owner: [[Percy Jackson]]

