Oaths, Pacts, and contracts are commonly used and traded by [[God]]s, and are both a symbol of currency and power. 

Notable Examples:
Pact of the big three: involving the abstinence of [[Zeus]], [[Poseidon]], and [[Hades]]
Stygian Oath: Oath upon the [[Styx]], usually enforced by [[Zeus]], affects only non-Divine

