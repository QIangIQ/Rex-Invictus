Part of the [[Greek Pantheon]]
Offspring of [[Primordial]]s and other Titans. Primarily situated in [[Mt. Othrys]], most Titans are either under imprisonment or reforming. 
Birthed [[God (greek)]]
Notable exclusions:
Aggressive:
[[Kronos]]
[[Oceanus]]
[[Perseus (Titan)]]
[[Atlas]]
[[Hyperion]]

Passive:
[[Selene]]
[[Helios]]
[[Calypso]]