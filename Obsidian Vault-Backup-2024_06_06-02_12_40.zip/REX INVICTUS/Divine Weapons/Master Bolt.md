[[Greek Pantheon]]
[[Divine Weapons]] of [[Zeus]]
As of the 51st millenium, its power has been imbued in every battleship under Zeus of the [[UOE]]

 [[Electrical Bolt Projection]]
        - [[Electric Discharge]]
        - [[Electrical Beam Emission]]
        - [[Lightning Bolt Projection]]