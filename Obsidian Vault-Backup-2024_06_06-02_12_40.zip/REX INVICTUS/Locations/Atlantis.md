[[Greek Pantheon]]
Kingdom under [[Poseidon]]
Residence of Prince [[Triton]]
Residence of Queen [[Amphitrite]]
Holds large amounts of Sea creatures, [[Nymphs]], [[Spirit]]s, and others