New [[Fields of Asphodel]], under the dominion of [[Hades]]
Official resting place of the dead of the [[UOE]]
All incoming [[Demigod]]s are refined into [[Spirit]]s