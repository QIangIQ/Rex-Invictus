Part of the [[Greek Pantheon]]
Residence of the [[Hesperide]]s
Former residence of [[Zoe Nightshade]]
Garden of the [[Golden Apples]]
Residence of [[Ladon]]

Explored by:
[[Hercules]]
[[Percy Jackson]]