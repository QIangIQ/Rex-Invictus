[[Greek Pantheon]]
Dominion of [[Hades]], encompassing [[Fields of Asphodel]], [[Fields of Punishment]], [[Elysium]]
