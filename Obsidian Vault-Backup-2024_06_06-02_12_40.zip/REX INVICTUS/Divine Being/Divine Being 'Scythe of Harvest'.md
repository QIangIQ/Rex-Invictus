Part of the [[Greek Pantheon]]
Kronos relies heavily upon his [[Divine Weapons]], as he has been sealed, and the weapon has not
[[Kronos' Scythe]]
A [[Divine Being]]