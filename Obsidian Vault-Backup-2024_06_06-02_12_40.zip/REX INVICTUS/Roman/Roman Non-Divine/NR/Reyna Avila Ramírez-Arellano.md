Daughter of [[Bellonna]]
Praetor of [[New Rome]]
Previous Crush on [[Jason Grace]]
Crush on [[Percy Jackson]]