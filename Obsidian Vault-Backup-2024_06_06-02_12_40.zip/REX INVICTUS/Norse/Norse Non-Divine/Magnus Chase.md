Part of the [[Norse Pantheon]]
[[Demigod]] son of [[Frey]]