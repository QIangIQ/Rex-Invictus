Taking Fire
Under Attack from Hostile