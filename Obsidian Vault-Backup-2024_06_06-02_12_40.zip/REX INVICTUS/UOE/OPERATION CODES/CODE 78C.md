Concerning Threat

Clearance:
[[CODE 24B]]
[[CODE 24C]]
[[CODE 24D]]

