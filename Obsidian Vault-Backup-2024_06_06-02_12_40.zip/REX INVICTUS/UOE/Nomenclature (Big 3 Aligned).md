All members of the [[UOE]]

[[Zeus]]
RT-ET-{Number}/"Callsign"
For weapon parts, Consult list (3) on [[Weapon Parts and Variants]]
Example:
[[Eleni Theodosia]]'s Honor guard:
RT-ET-Primus/"Eagle Eye"
RT-ET-Duox/"Earl"
RT-ET-Trex/"Prism"
RT-ET-Quaxtro/"Thundercloud"
RT-ET-Quintus/"Therapist"
RT-ET-Hexas/"Banshee"
RT-ET-Septimus/""
RT-ET-Octus/""
RT-ET-Ninpha/""
RT-ET-Dex/""
****
[[Poseidon]]
TW-SP-{ - - - - }{Hellenistic alphabet}-"Callsign"

Example:
[[Stephanos Pyrrhus]]'s Honor Guard:
ɩ κ
TW-SP-LNCE/α "LAWBREAKER"
TW-SP-ARQB/β "KNIGHT"
TW-SP-HMMR/Ɣ "PEACEKEEPER"
TW-SP-SWRD/∆ "SPECTRE"
TW-SP-MSKT/ε "AURORA"
TW-SP-XPHS/ζ "NOVA"
TW-SP-SCPL/θ "PIERCER"
TW-SP-SPIR/𝜂 "ECLIPSE"
TW-SP-CLVR/𝝀 "BARON"

[[Hades]]
{- - -}/(S or SNV) - {latin/greek}
****
Example:
[[Charon's Heralds]]'s Emissaries:
223/S-CORVUS
198/S-MORTALIS
172/S-NOCTURNE
153/S-REQUIESCAT
152/S-EN PACE
131/S-NEKROS
112/S-KERES
099/SNV-SEPULCRUM
089/SNV-INTERITUS
069/SNV-CADAVER
055/SNV-KATABASIS
041/SNV-EPITAPHIOS
030/SNV-ASH
019/SNV-EXCECUTIONER
017/SNV-VODOO
001/SNV-ULTIMA