BML/P07CT-C/12
12-Cell Vertical Missile Launcher/Stationary Laser Turret Deployer

ME-E-145 ETSUJIN 
Kamikaze Drone deployer

IA-C01W1
Ultra high frequency resonance breaker

DF-GA-08 HU-BEN
Generic GL

PB-033 "Backyard BBQ"
Flamethrower


