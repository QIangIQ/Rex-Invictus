Protector of the harbor
