Part of the [[Greek Pantheon]]
[[REX INVICTUS/Definitions/Titan]]