Part of the [[Greek Pantheon]]
King of [[REX INVICTUS/Definitions/Titan]]s
Husband of [[Rhea]]
Son of [[Oceanus]] and [[Gaia]]
[[Divine Being 'Scythe of Harvest']]
