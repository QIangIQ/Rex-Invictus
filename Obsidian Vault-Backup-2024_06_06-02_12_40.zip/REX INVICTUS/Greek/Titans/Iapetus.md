[[Greek Pantheon]]
[[Titan]] of mortal life

[[Clymene]] (wife)
Brothers:
[[Oceanus]], [[Hyperion]], [[Krios]], [[Koios]], [[Kronos]], [[Arges]], [[Brontes]], [[Steropes]], [[Cottus]], [[Gyges]], and [[Briares]] 
Sisters:
[[Theia]], [[Tethys]], [[Themis]], [[Phoebe (Titan)]], [[Mnemosyne]], [[Rhea]] and [[Aphrodite]]