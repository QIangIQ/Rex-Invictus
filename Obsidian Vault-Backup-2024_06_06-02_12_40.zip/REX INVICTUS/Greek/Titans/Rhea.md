Part of the [[Greek Pantheon]]
Wife of [[Kronos]]
Mother of [[REX INVICTUS/Definitions/Titan]]s
Daughter of [[Oceanus]] and [[Gaia]]