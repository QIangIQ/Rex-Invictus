[[Primordial]]
Member of the [[Greek Pantheon]]

Wields [[Eternal Sands]]

Relationships:
Brother of [[Nyx]]
Brother of 

|                                                                                                                                                                                         |
| --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [](https://riordan.fandom.com/wiki/Chaos)[Chaos](https://riordan.fandom.com/wiki/Chaos): Protogenos of the Void and Creation                                                            |
| [](https://riordan.fandom.com/wiki/Ouranos)[Ouranos](https://riordan.fandom.com/wiki/Ouranos): Protogenos of the Sky and Heavens                                                        |
| [](https://riordan.fandom.com/wiki/Gaea)[Gaea](https://riordan.fandom.com/wiki/Gaea): Protogenos of the Earth and Nature                                                                |
| [](https://riordan.fandom.com/wiki/Tartarus_(primordial))[Tartarus](https://riordan.fandom.com/wiki/Tartarus_(primordial)): Protogenos of the Pit                                       |
| [](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Pontos)[Pontos](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Pontos): Protogenos of the Sea             |
| Erebos: Protogenos of Darkness and Mist                                                                                                                                                 |
| [](https://riordan.fandom.com/wiki/Nyx)[Nyx](https://riordan.fandom.com/wiki/Nyx): Protogenos of Night                                                                                  |
| [](https://riordan.fandom.com/wiki/Akhlys)[Akhlys](https://riordan.fandom.com/wiki/Akhlys): Protogenos of Misery and Poison                                                             |
| [](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Elpis)[Elpis](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Elpis): Protogenos of Hope                   |
| [](https://riordan.fandom.com/wiki/Hemera)[Hemera](https://riordan.fandom.com/wiki/Hemera): Protogenos of Day                                                                           |
| [](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Aither)[Aither](https://riordan.fandom.com/wiki/List_of_mentioned_characters#Aither): Protogenos of Upper Air and Light |
| [](https://riordan.fandom.com/wiki/Eros)[Eros](https://riordan.fandom.com/wiki/Eros): Protogenos of Desire and Love (according to some myths)                                           |
| [](https://riordan.fandom.com/wiki/Ourae)[Ourae](https://riordan.fandom.com/wiki/Ourae): Protogenoi of Mountains                                                                        |
| Thalassa: Protogenos of the Sea                                                                                                                                                         |
| Chronos: Protogenos of Time and Eternity                                                                                                                                                |
| Ananke: Protogenos of Inevitability and Fate                                                                                                                                            |
| Phanes: Protogenos of Creation, Procreation and Generation of New Life                                                                                                                  |
| Nesoi: Protogenoi of Islands                                                                                                                                                            |
| Physis: Protogenos of Nature                                                                                                                                                            |
| Hydros: Protogenos of Fresh Water                                                                                                                                                       |
| Moros: Protogenos of Impending Doom                                                                                                                                                     |