Part of the [[Greek Pantheon]]
[[Primordial]] of [[Tartarus (Realm)]]
[[Divine Being 'Sovereign of the Abyss']]