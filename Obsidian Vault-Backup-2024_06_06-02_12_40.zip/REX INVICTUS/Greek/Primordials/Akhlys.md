Part of the [[Greek Pantheon]]
[[Primordial]] of Misery and Poison
Almost died to [[Percy Jackson]] and [[Annabeth Chase]] while on [[Tartarus (Realm)]]