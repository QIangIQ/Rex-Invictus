Former Lieutenant of [[Artemis]]
Former Lieutenant of [[Hunters of Artemis]]
Daughter of [[Atlas]], a [[Hesperide]]
Kicked out of [[Garden of the Hesperides]] by betraying them and giving [[Riptide]] to [[Hercules]]