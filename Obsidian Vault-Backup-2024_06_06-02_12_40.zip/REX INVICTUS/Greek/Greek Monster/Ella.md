Part of the [[Greek Pantheon]]
[[Monsters (Greek)]]
A [[Harpy]]
Blessed by [[Athena]]
