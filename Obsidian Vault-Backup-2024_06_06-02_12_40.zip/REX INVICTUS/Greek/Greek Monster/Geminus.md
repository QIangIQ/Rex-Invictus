[[Greek Pantheon]]
[[Monsters (Greek)]]
Race of half-human, half-snakes
self proclaimed last children of [[Gaia]]