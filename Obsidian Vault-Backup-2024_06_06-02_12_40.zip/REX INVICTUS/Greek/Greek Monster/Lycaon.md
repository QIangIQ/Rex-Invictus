[[Greek Pantheon]]
Pack leader of [[Werewolves]] Rival of [[Lupa]] and [[Hounds of Artemis]]