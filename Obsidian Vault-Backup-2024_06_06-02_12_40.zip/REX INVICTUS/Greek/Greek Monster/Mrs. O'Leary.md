Part of the [[Greek Pantheon]]
Descendant of [[Cerberus]]
[[Monsters (Greek)]]
A [[Hellhound]] previously under [[Quintus]]
Current owner: [[Percy Jackson]]

[[Heat Absorption]]
[[Fire Attacks]]
[[Pyrokinetic Regeneration]]
