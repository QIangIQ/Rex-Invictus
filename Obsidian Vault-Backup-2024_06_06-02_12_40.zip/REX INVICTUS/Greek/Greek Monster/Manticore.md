Part of the [[Greek Pantheon]]
[[Monsters (Greek)]], uses poison
Descendant of [[Echidna]] and [[Typhon]]