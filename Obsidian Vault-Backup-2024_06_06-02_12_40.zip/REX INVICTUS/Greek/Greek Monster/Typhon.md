Part of the [[Greek Pantheon]]
[[Monsters (Greek)]]
Son of [[Tartarus (Primordial)]] and [[Gaia]]
Husband of [[Echidna]]