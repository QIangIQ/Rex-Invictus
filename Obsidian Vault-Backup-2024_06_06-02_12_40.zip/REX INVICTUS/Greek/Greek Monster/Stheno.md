Part of the [[Greek Pantheon]]
A [[Gorgons]]
Sister of [[Medusa]] and [[Euryale]]
