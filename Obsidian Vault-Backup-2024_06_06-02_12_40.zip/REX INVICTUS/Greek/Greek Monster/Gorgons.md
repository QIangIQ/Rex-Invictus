Part of the [[Greek Pantheon]]
[[Monsters (Greek)]]
Killed by [[Perseus (Hero)]]
