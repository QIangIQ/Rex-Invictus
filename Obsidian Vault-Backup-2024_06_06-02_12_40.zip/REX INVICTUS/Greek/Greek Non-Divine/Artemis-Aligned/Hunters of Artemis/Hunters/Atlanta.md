Part of the [[Greek Pantheon]]
Daughter of [[Apollo]]
Apothecary