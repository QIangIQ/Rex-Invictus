Part of the [[Greek Pantheon]]
In relationship with [[Hemithea]]
Daughter of [[Hephaestus]]