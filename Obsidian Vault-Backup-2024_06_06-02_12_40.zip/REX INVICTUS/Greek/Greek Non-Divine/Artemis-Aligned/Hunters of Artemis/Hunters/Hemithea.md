Part of the [[Greek Pantheon]]
In relationship with [[Josephine]]
Daughter of [[Hecate]]