Part of the [[Greek Pantheon]]
Member of [[Camp Half-Blood]]
Oracle of [[Apollo]]
Previous relationship with [[Percy Jackson]]