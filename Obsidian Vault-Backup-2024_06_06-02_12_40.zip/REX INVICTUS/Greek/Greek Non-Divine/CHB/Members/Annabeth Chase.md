Part of the [[Greek Pantheon]]
[[Demigod]]
Member of [[Camp Half-Blood]]
Daughter of [[Athena]]
Previous girlfriend of [[Percy Jackson]]
Ambassador to [[Egyptian Pantheon]]
Ambassador to [[Norse Pantheon]]
Ambassador to [[Indian Pantheon]]

