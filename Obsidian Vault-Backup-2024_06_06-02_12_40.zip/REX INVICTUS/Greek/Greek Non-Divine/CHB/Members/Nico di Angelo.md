Part of the [[Greek Pantheon]]
[[Demigod]]
Member of [[Camp Half-Blood]]
Son of [[Hades]]