Part of the [[Greek Pantheon]]
Consort of [[Dionysus]]
Navigated the [[Labyrinth]]
