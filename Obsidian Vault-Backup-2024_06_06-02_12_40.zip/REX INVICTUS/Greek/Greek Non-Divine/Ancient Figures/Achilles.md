Part of the [[Greek Pantheon]]
Son of [[Thetis]]
Hero of the [[Trojan War]]
Bathed in the [[Styx]]
