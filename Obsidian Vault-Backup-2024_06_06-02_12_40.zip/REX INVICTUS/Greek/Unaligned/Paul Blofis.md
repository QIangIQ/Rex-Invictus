Husband of [[Sally Jackson]]
Stepfather of [[Percy Jackson]]