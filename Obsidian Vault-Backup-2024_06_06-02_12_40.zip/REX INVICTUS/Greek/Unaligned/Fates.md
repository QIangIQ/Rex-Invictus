Part of the [[Greek Pantheon]]
[[God]]s
Supposed Daughters of [[Zeus]] and [[Themis]]
Blessed by [[Anake]]
Compesed of:
[[Clotho]]
[[Lachesis]]
[[Atropos]]