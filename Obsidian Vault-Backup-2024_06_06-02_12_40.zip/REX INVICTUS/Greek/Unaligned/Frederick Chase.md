Previous lover of [[Athena]]
Father of [[Annabeth Chase]]