Part of the [[Greek Pantheon]]
Sister of [[Percy Jackson]]
Daughter of [[Poseidon]] and [[Amphitrite]]
Brother of [[Triton]]
[[god]] of violent sea and storms.
