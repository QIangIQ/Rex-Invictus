Part of the [[Greek Pantheon]]
Half man, half horse. Related to [[Ichthyocentaurs]]
Notables:
[[Party Ponies]]
[[Chiron]]