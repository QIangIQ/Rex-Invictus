Part of the [[Greek Pantheon]]
River of Pain, ruled by [[Acheron]]