[[God]]
Part of the [[Greek Pantheon]]
Greatest son of [[Apollo]]
Favored by [[Athena]]
Tutored under [[Chiron]]
Ability to reverse death
Incurred anger from [[Hades]] and [[Thanatos]]
Charm spoke by [[Piper]] to revive [[Leo]]
