Part of the [[Greek Pantheon]]
[[God]] of wildlife, revered by [[Centaur]]s, [[Nymphs]], [[Satyr]]s, and similar Nature-Aligned creatures
Son of [[Hermes]]