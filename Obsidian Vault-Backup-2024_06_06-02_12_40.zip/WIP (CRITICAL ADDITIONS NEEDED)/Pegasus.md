Son of [[Medusa]]
Brother of [[Chrysaor]]