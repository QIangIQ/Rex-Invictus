Military Advanced Infantry Directorate
"Mors Arma Invicta Dirigit"

Elite All-female PMC hired under the Institute Academy
Armored infantry division
In charge of direct assaults and straightforward engagements
