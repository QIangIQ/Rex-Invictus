Belgian literary society
Contributors:
Rodenbach
Demolder
Verhaern
Maeterlinck
Lerberghe
Giraud
Eekhoud
Lemonnier
Jennart