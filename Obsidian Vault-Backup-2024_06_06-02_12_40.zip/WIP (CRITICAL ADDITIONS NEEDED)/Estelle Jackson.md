[[Greek Pantheon]]
Daughter of [[Sally Jackson]] and [[Paul Blofis]]
Brother of [[Percy Jackson]]