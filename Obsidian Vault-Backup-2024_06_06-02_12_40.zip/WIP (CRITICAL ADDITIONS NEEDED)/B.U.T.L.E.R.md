Battalion for Urban Tactical Law Enforcement and Reconnaissance
"Benevolentia Unitas Tribuit Lucem Et Resurgendum"
Elite All-male PMC hired under the Institute Academy
Infiltration and counter-intelligence operations
