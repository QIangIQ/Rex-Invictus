Catechist
Perdition
The pagliacci
Him within the moon
Ad Valorem tax
qanat
Dread-Not
Disciples of the lesser keys
Major demons underneath lesser demon kings
Lammergeier
Eurynomoi
Meritocracy
Condottiero
Valkyries: choosers of the slain
Marcus Pocius Cato
Anne Bonny and Mary Read
Ching Shih
Gráinne O'Malley
Jeanne de Clisson
Itzpapalotl 
Frances Clayton
Khutulun
Scathach
Enyo
Italo Calvino
Tanit
Candelabrador
**from each according to his ability, to each according to his need**
Kyrie
Actuary
Lingua primordia
Lingua aeternae
Lingua moderna
**lesch-nyhan**