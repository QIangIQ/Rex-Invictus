Regenerative cocktail custom-tailored to each individual person
[[Percy Jackson]]:
- 10% [[Poseidon]]'s Blood
- 10% [[Atlantis]] Saltwater
- 30% Nectar
- 30% Crushed Ambrosia
- 5% Norepinephrine
- 5% Adrenaline
- 5% Concentrated Morphine
- 5% Liquid Hemostat