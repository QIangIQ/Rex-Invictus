North sector [[MLO]] & [[PMC]] organization. 
Characterized by easy-to-hire services.
HQ located in the far north, but their reach spreads across the galaxy