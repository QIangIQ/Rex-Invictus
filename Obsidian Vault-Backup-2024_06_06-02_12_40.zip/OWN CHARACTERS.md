Katherine Markson
	American roots
Ramael Marcusson
	Norse roots
Arias Santer “Ayre”
	Tochter Aus Elysium
	Pilots Untarnished tempest
	Divine pariah
Lysis Arenberg
	Horse of Arenberg
	Legacy of Athena, Ares, Zeus, Aphrodite
Aldric Thornvale [Germanic]
	Older, blonde, cloaked, wields staff
Astrid Ravenshield [Germanic]
	Ravenguard, similar to Annabeth, braided
Demetrius Lykourgos
Pericles Sophocles
	Tactical commander above UOE Divine Crusader
Kleon Alkibiades
Themistocles Xenophon
Lycurgus Nikias
Solon Themistokles
Callista Euphemia
Cleostrate Aristomache
Hipparchia Lysistrate
Themista Melantho
Xanthippe Theano
Thaisa Aspasia
	Olive skin, green eyes
	Nymph origin
	Musician & storyteller
Nikos Pyrrhus
	Battle scarred armor. 
	WW2 Veteran, now in COS
Branwen Llywelyn [Welsh]
	Nature alignment
	Healer, herbalist
	Lives in deep welsh countryside
Rhys Morgan [Welsh]
	Hunter-tracker
	Dog of Cernunnos
	Hunting Cernunnos for opportunity of freedom
Freja Bjornsdottir [Norse]
	Wears ornate jewelry and flowing garments
	Loyal to her friends and family
	Shieldmaiden into Valk
Elowen Greenwood [English (Arthurian)]
	Druidess, ethereal
	Guard of Upper World Tree (elf)
Rowan Blackwood [English (Arthurian)]
	Poisoner, assassin
	Insane (?)
Gabriel Stone [Christian]
	Battle-Priest
	Grand Sermons
Seraphina Grace [Christian]
	Clothing w/ shades of white and gold and blue
Hiroki Yamamoto [Jap]
	Samurai serving the Yamamoto clan
Mei Nakamura [Jap]
	Dancer/Assassin
	Shrine Maiden
Arjun Devi
	Bow
	Prince of the kingdom of Hastinapur
Priya Devi
	Twin sister 
	Healer
Aria Sterling
	Apostle of Zodiacs
Orion Blackwood
	Apostle of Leo
	Practitioner of Dark Arts, communes with Demon Apostles
Lilith Darkheart [Demonic]
	Succubus, Granddaughter of Lilith
Damien Nightshade [Demonic]
	Commander of the 5th Legion of Basphomet
Nefertari Amunet [Egyptian]
	High priestess who serves the temple of Amun-Ra
Ibrahim Kemet [Egyptian]
Li Wei [Chinese]
	Qi Transformation Realm
Warrior with enhanced CQC HTH abilities
	Outer Disciple of High Heaven Pavilion
Mei Tang [Chinese]
	Nascent Soul Realm
	Young Lady of the Tang Family
	Poisoner
Yang Qiang [Chinese]
	Member of the Yang Family
	Void Palace outer disciple
	Half-Step Open Heaven realm
Yang Kai [Chinese]
Zephon Darkbane [Demonic]
	Fallen Angel
	Lustful
Sylas Shadowcaster  [Demonic]
	Necromancer
	Communed with Chaos
Brother-Captain Tiberius Vox [40k]
	Faction: Astartes 
	Chapter: Blood Angels
	465 years of service (4 Service studs)
Inquisitor Lysandra Voss [40k]
	Ordo Hereticus
	37 Years old
Tech-Priestess Kappa-Kappa-Epsilon-57 “Aurelia” [40k]
	Magos Biologis
	233 Years
Kaela Mensha Asukhar [40k]
	Exarch of the Howling Banshees
	14991 Years Old
Pygmalion
Galatea
