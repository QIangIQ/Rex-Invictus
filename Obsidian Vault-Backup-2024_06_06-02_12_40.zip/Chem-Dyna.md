Chemical production company
Specializes in cheap, easy to produce, safe chemicals in bulk