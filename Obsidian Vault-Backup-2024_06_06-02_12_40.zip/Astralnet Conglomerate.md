Large-scale merchant-transport-trader coalition
Largest available repository of trading routes and safe routes through the [[Tachyon Bridge Network]]
Also responsible for the initial concept of the [[Noosphere]]
Currently carrying out the [[Gaia Paradigm]], part of the greater [[Eden Project]]