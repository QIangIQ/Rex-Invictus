Corporations that operate within the [[UOE]], or alongside it

| [[Akvavit Mercenary Liaison Organization]]                 |
| ---------------------------------------------------------- |
| [[Aldra Mercenary Liaison Organization]]                   |
| [[ARES technicha]]                                         |
| [[Arisawa Heavy Industries]]                               |
| [[Aspina Aggregates]]                                      |
| [[Astralnet Neural Solutions]]                             |
| [[Bernard & Felix Foundation]]                             |
| [[Blackstar Crucible]]                                     |
| [[Chem-Dyna]]                                              |
| [[Deadalus Reseach Evaluation & Developement Corporation]] |
| [[Durham Aerospace]]                                       |
| [[Everaude]]                                               |
| [[Evergreen Family]]                                       |
| [[Hawkes Prescison Instruments]]                           |
| [[Interior Union]]                                         |
| [[Leone-Mecchanica]]                                       |
| [[Melinite]]                                               |
| [[Mercenary Solutions and Advisory Corporation (MSAC)]]    |
| [[North Central Positronics]]                              |
| [[Proxima Armaments]]                                      |
| [[Rayleonard]]                                             |
| [[Rosenthal]]                                              |
| [[Scaperelli Knetics]]                                     |
| [[Serpentine Baylock]]                                     |
| [[Tian-Qiang Heavy Foundries]]                             |