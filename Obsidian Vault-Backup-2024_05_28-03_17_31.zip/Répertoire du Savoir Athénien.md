The grandest collection of knowledge of the gods. Hyper-intelligent AI 
[[Greek Pantheon]]
Under direct supervision by [[Athena]]
[[UOE]]
