[[Greek Pantheon]]
Forged out of [[Gaia]] herself, and imbued with the Sands from [[Chronos]]'s [[Eternal Sands]].
Smelted with [[Kronos]]'s own blood, manifestation of his power. 
Foci and unlocker of his former power