[[Greek Pantheon]]
Shield of [[Athena]], 
Classified as a [[Divine Weapons]], part of a set of 2, the other being [[Pallas]]