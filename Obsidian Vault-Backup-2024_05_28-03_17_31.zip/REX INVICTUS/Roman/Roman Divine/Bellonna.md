Part of the [[Roman Pantheon]]
Roman [[God]] of War strategy
Mother of [[Reyna Avila Ramírez-Arellano]]