Potential Pilot names for [[UOE]] [[Titan (Mech)]] Pilots
Rosseau
Focault
Cerelli
Herrman
Keyes
Frued
Friedman
Ashigaru
Taregashiman
Iyeyasu
Toyotomi
Tokugawa
Yoshishige
Ashmead
Cocivullette

IA-C01W2/ML "Osh"
