[[UOE]]
Grand Crusade-Fleet of [[Charon]] and [[Hades]]
Special [[Titan (Mech)]]s for combat