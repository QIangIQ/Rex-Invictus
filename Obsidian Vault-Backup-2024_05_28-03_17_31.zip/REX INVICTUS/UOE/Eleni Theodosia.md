[[Demigod]] daughter of [[Zeus]]
[[UOE]]
Commander of [[UOE Divine Crusader]]
