Part of the [[Greek Pantheon]]
Ocean & Lake spirits under [[Poseidon]]
Granddaughters of [[Titan]]s, [[Oceanus]] and [[Tethys]]