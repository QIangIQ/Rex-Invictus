Part of the [[Greek Pantheon]]
[[Primordial]] of [[Tartarus (Realm)]]