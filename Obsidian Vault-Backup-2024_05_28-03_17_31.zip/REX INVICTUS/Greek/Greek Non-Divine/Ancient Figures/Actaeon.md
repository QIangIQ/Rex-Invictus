Part of the [[Greek Pantheon]]
Tutored under [[Chiron]]
Transformed into deer when spying on [[Artemis]]
