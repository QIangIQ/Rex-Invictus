Part of the [[Greek Pantheon]]
Tutored under [[Chiron]]
Physically the strongest of the Achaeans
Participated in the [[Trojan War]]