Part of the [[Greek Pantheon]]
[[Demigod]]
Daughter of [[Ares]]
[[Ares' Cabin]] Counselor/Leader
Girlfriend of [[Chris Rodriguez]]
Member of [[Camp Half-Blood]]
Explored the [[Labyrinth]]