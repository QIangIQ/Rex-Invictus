
Part of the [[Greek Pantheon]]
Domesticated Wolves and [[Werewolves]] under [[Hunters of Artemis]]
Receive Reinforcements form [[Lupa]] and the [[Wolf House]]
Enhanced detection towards [[Lycaon]] and his pack

