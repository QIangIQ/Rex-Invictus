Part of the [[Greek Pantheon]]
Daughter of [[Demeter]]
Rank and file