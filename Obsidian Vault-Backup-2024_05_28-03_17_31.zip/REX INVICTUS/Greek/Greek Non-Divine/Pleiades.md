[[Greek Pantheon]]
7 Daughters pf [[Atlas]]
Trained [[Artemis]] and [[Dionysus]]