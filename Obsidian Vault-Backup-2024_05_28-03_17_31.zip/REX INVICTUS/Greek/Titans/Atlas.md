Part of the [[Greek Pantheon]]
[[REX INVICTUS/Definitions/Titan]]
son of [[Iapetus]] and [[Clymene]]
Father of the [[Hesperide]]s, [[Zoe Nightshade]], [[Calypso]], [[Pleiades]]
Siblings:
