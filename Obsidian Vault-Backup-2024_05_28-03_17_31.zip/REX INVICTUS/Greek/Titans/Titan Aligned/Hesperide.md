Part of the [[Greek Pantheon]]
Daughters of [[Atlas]] and [[Hesperis]]
Tend to [[Garden of the Hesperides]]
