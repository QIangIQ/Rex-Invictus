[[Greek Pantheon]]
Guards [[Thalia's Pine Tree]] and [[Golden Fleece]] in [[Camp Half-Blood]]