[[Greek Pantheon]]
[[Monsters (Greek)]]
Generally all under [[Lycaon]] or [[Lupa]]