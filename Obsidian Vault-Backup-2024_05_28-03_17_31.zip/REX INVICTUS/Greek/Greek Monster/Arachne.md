[[Monsters (Greek)]]
[[Greek Pantheon]]
Rival of [[Athena]]'s sewing competition,
battled [[Annabeth Chase]] and [[Percy Jackson]] over [[Athena Parthenos]] before falling into [[Tartarus (Realm)]]
