Part of the [[Greek Pantheon]]
Son of [[Zeus]]
[[God]]
Brother of [[Artemis]]
Brother of [[Athena]]
Brother of [[Dionysus]]
Brother of [[Hephaestus]]
[[Divine Being 'Eternal Warmonger']]
Main title: [[Mars Ultor]]
Demigods:
[[Clarisse]]

