Part of the [[Greek Pantheon]]

Daughter of [[Oceanus]]
Ex-lover of [[Ares]]
Ex-Wife of [[Hephaestus]]
[[God]]
