Part of the [[Greek Pantheon]]
[[God]]
Daughter of [[Kronos]] and [[Rhea]]
[[Divine Being 'Blessed of Grain']]