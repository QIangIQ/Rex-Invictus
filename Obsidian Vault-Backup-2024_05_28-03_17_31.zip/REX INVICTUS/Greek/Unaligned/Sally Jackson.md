Ex-lover of [[Poseidon]]
Mother of [[Percy Jackson]]
Wife of [[Paul Blofis]]
Mother of [[Estelle Jackson]]