[[Greek Pantheon]]
The legendary residences of [[God (greek)]]s and [[Olympians]]. Located approximately 150km from [[Olympus]]/[[Olympus Primaris]]