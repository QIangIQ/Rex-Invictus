Roman city, counterpart to [[Camp Half-Blood]], holds numerous ghosts, [[Spirit]]s, Roman [[Demigod]]s, and [[Legacy]]s
Centers of worship towards the Roman [[God]]s
[[Terminus]] guards the borders, surrounded by [[Tiber]]
