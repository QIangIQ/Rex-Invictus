Creatures hostile to human of mythic origins, encompasses

[[Monsters (Roman)]]
[[Monsters (Greek)]]
[[Monsters (Japanese)]]
[[Monsters (Egyptian)]]
[[Monsters (Norse)]]
