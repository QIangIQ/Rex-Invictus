Part of the [[Greek Pantheon]]
Owned by [[Ariadne]]
Tool to navigate the [[Labyrinth]]
Hated by [[Quintus]], and therefore [[Daedalus]]