[[Greek Pantheon]]
Material commonly used to forge semi-[[Divine Weapons]], as it possesses the ability to hurt both [[Monsters (Greek)]] and [[Monsters (Roman)]], along with most [[Monster]]s in general.

It is a Bronze sanctified by either a demigod, apostle, or the [[God]] [[Hephaestus]] himself