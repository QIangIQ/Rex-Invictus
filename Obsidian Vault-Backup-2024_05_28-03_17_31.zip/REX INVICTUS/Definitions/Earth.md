Manifestation of [[Gaia]]
Location of most of the pantheons presently

[[Greek Pantheon]]
[[Roman Pantheon]]
[[Norse Pantheon]]
[[Japanese Pantheon]]
[[Egyptian Pantheon]]
