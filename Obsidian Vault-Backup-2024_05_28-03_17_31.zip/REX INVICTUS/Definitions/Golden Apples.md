Part of the [[Greek Pantheon]]
Divine gift from [[Zeus]] to [[Hera]] as a marriage gift. 
Currently resides in [[Garden of the Hesperides]], guarded by [[Ladon]]
