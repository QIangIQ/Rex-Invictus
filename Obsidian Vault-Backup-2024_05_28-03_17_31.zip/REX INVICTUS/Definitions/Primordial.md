Part of the [[Greek Pantheon]]
Manifestations of Reality. Borne from [[Chaos]], they are thoughts formed by mass, and represent their aspects. Most stay away from [[Earth]], except [[Gaia]] and [[Ouranos]]

Primordials:
[[Chaos]] Protogenos of the Void and Creation
[[Ouranos]]Protogenos of the Sky and Heavens
[[Gaia]] Protogenos of the Earth and Nature
[[Tartarus (Primordial)]] Protogenos of the Pit
[[Pontus]] Protogenos of the Sea
[[Erebus]] Protogenos of Darkness and Mist
[[Nyx]] Protogenos of Night
[[Akhlys]] Protogenos of Misery and Poison
[[Elpis]] Protogenos of Hope
[[Hemera]] Protogenos of Day
[[Aether]] Protogenos of Upper Air and Light
[[Eros]] Protogenos of Desire and Love (according to some myths)
[[Ourae]] Protogenoi of Mountains
[[Thalassa]]: Protogenos of the Sea
[[Chronos]]: Protogenos of Time and Eternity
[[Ananke]]: Protogenos of Inevitability and Fate
[[Phanes]]: Protogenos of Creation, Procreation and Generation of New Life
[[Nesoi]]: Protogenoi of Islands
[[Physis]]: Protogenos of Nature
[[Hydros]]: Protogenos of Fresh Water
[[Moros]]: Protogenos of Impending Doom
