Military Advanced Infantry Directorate
"Mors Arma Invicta Dirigit"

