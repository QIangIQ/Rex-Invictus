Battalion for Urban Tactical Law Enforcement and Reconnaissance
"Benevolentia Unitas Tribuit Lucem Et Resurgendum"