An Ultra-Heavy Dreadnought is a flagship of one of the [[Olympians]]
Average length varies, but stays around the 10000 meter ~ 35000 meter range