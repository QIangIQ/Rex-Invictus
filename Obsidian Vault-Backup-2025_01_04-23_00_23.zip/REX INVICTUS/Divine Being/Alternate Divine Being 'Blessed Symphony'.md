Part of the [[Greek Pantheon]]
A [[Divine Being]]