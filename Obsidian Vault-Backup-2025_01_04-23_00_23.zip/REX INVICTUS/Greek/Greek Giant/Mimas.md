[[Greek Pantheon]]
[[Giant (Greek)]]
son of [[Gaia]]
Born to oppose [[Hephaestus]]
Born
