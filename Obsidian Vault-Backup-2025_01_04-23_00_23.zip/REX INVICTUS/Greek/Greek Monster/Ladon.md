Part of the [[Greek Pantheon]]
[[Monsters (Greek)]], a dragon
Resides in the [[Garden of the Hesperides]], guarding the [[Golden Apples]]