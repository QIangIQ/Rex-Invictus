Part of the [[Greek Pantheon]]
[[Monsters (Greek)]]
Parents were either [[Pontus]] and [[Gaia]], or [[Tartarus (Primordial)]] and [[Nemesis]], or else they were born from the blood of castrated [[Ouranos]].