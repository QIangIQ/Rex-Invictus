Part of the [[Greek Pantheon]]
a [[Manticore]], agent of [[Atlas]] and [[Kronos]]