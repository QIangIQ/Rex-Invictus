Part of the [[Greek Pantheon]]
[[Monsters (Greek)]]
Sister of [[Stheno]] and [[Medusa]], all [[Gorgons]]