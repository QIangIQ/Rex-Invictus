[[Greek Pantheon]]
[[Spirit]]s of negative emotions