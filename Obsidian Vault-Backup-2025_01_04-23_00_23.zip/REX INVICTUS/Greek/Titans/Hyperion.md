[[Titan]]Part of the [[Greek Pantheon]]
[[REX INVICTUS/Definitions/Titan]] [[god]] of heat, heavenly light and power