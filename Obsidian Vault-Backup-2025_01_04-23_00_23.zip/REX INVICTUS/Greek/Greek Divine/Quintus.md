Part of the [[Greek Pantheon]]
Alternate form of [[Daedalus]]
