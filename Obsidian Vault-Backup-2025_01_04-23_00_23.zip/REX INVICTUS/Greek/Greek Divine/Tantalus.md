Part of the [[Greek Pantheon]]
[[Mortal]] son of [[Zeus]]
Temporary director of [[Camp Half-Blood]]