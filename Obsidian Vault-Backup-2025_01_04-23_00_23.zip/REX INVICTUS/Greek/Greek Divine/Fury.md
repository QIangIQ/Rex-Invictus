Part of the [[Greek Pantheon]]
Servants of [[Hades]], also known as Erinyes.
Descendants of [[Ouranos]]'s [[Ichor]]
