Part of the [[Greek Pantheon]]
[[Monsters (Greek)]] of [[Tartarus (Primordial)]]
Can be controlled by [[Hades]]
Children of [[Nyx]] and [[Cerberus]]

