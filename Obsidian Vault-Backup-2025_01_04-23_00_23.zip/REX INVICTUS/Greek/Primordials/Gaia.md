Part of the [[Greek Pantheon]]
[[Primordial]] of the [[Earth]]
[[Divine Being 'Great Mother']]
Wife of [[Ouranos]]

Abilities:
 - [[Crystal Manipulation]]
- [[Density Manipulation]]
- [[Gravitational Manipulation]]
- [[Earth Constructs]]
- [[Earth Purification]]
- [[Superior Human Physiology]]