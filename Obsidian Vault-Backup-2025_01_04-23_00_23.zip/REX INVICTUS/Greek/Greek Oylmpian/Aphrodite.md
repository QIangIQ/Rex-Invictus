Part of the [[Greek Pantheon]]
[[Divine Being 'Great Love']]
[[Alternate Divine Being 'Heart of Calamity']] 

Daughter of [[Oceanus]]
Ex-lover of [[Ares]]
Ex-Wife of [[Hephaestus]]
[[God]]
