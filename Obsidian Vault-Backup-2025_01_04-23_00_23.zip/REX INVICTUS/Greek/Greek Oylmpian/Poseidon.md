Part of the [[Greek Pantheon]]
[[God]]
Brother of [[Zeus]]
Brother of [[Hades]]
Brother of [[Hestia]]
Brother of [[Demeter]]
Brother of [[Hera]]

[[Divine Being 'King of Atlantis']]

Abilities:
- [[Hydro-Telekinesis]]
- [[Property Manipulation]]
    - [[Viscosity Manipulation]]
- [[State Manipulation]]
- [[Water Detection]]
- [[Hydrokinetic Regeneration]]
- [[Blood Manipulation]]
- [[Superior Human Physiology]]