Goddess of light and moon

