Assisting women in child-birth
