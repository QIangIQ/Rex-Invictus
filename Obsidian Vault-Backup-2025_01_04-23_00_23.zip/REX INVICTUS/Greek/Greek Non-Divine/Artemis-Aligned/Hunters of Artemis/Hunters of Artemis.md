Part of the [[Greek Pantheon]]
Hunters under [[Artemis]]

Members (Active):
1. [[Atlanta]]
2. [[Celyn]]
3. [[Hemithea]]
4. [[Josephine]]
5. [[Naomi]]
6. [[Phoebe]]
7. [[Thalia Grace]]