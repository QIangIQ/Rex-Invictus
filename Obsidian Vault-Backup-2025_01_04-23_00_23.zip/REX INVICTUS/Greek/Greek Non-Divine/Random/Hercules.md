Roman and Greek demigod of [[Zeus]]
Once tricked [[Zoe Nightshade]]