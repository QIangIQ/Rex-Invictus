Minor Threat

Clearance:
[[CODE 24A]]
[[CODE 24B]]
[[CODE 24C]]

