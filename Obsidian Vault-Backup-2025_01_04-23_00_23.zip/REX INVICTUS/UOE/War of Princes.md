TIMELINE
- 16212.11.4.1
	- [[God (greek)]] announced the implementation of [[Legacy]]s as [[Demigod]]s, due to rising amount of [[Divine Power]] due to the explosive population increase of the the events of [[The Great Expansion]]
	- Nicknamed the "[[Second-Born Demigod]]s" by the original now [[Pure Demigod]]s, it caused great dissent among the upper levels of government and military, as the people in places of such power, commonly [[Pure Demigod]], now felt as if their position and power were undermined by the arrogance of the gods.
- 16213.1.1.1
	- [[UOE]] [[Demigod]] [[Lysandra Voss]], one of the only [[Pure Demigod]]s from [[Zeus]] alive at the time, declared war on wider Empire due to escalating tensions between [[Pure Demigod]] and relationship with the colder [[God (greek)]] and their loyal [[Second-Born Demigod]]s, due to a conflict upon [[Justicar Primaris]], which resulted in a severe injury of one [[Hiarchia Lysistrate]], and the deaths of 3 [[Second-Born Demigod]]s 
		- Named IIIIIIIIIIIIII IIIIIIIIIIIII, born 16183.6.2.5, Male, Son of IIIIIIIII
		- Named IIIIIIIIIIIIIIIIIII III, born 16183.6.2.5, Male, Son of IIIIIIIIIIIIIIIII
		- Named IIIIIIIIII (N/A),  born 161873.1.1.3, Female, Daughter of IIIIIIIIIIIIIIIIIIIII
- 16213.1.2.6
	- The belligerents, now named [[The Princes]], quickly found themselves severely outnumbered nearly a hundredfold in terms of [[Divine Being]]s alone, and quickly banded together in order to protect themselves against the [[Second-Born Demigod]] and their [[Mortal]] subordinates
	- Fleeing to the the North-Western section of the galaxy, they quickly settled and fortified the Bulwark-system newly named as the  [[Voss System]] (originally System 12-6322).
		- Due to the close borders with the [[Japanese Pantheon]], which bordered its South-Western [[TBN Relay]], and a defunct northern [[TBN Relay]], the only relevant and operational Relay laid in the eastern direction, which conveniently, hosted two shattered [[Glass Worlds]] laid silent, with debris which clustered around the gravitic stabilizers of the Relay, which would later be named the [[Yamamoto Chokepoint Relay]]
- 16213.5.2.2
	- With the Vanguard Fleet quickly arriving, the slowly-fortifying Princes had few choices to effectively counter the spearhead of the [[UOE]]. 
	- Even with the vast technological and naval supremacy, the Princes were still in the process of fully developing the few habitable planets around the Tri-Star system.
		- A notable example to this, is that even its first [[Dyson Sphere]], which was planned around [[Voss III]], picked specifically for its small size and relative distance from the two other stars ([[Voss I]] & [[Voss II]])had barley finished its primary satellite phase, which barely started generating energy, before the first ships had breached the Tachyon Relays.
	- The forces of the belligerents and the invading fleet is as follows:
		- Belligerents: [[The Princes]]
			- Battleships
				Battleships:
					I. [[Corvette]] - ~14,000 [[Icarus Pattern]]
					II. [[Light Frigate]] - 2,011 [[Mastodon Pattern]]
					III. [[Frigate]] - ~7,000 [[Hammerhead Pattern]]
					IV. [[Heavy Frigate]] - 931 [[Arcturus Pattern]]
					V. [[Destroyer]] - 410 [[Radovrrich Pattern]]
					VI. [[Cruiser]] - 430 [[AnnChase Pattern]]
					VII. [[Dreadnought]] - 20 [[Jackson Pattern]]
			- Commanders:
				- [[Lysandra Voss]] - Supreme Elect Admiral
				- [[Solon Themis]] -  SIC
				- [[Astrid Arenberg]] - [[Naval Commander Class I]]
				- [[Kleon Arenberg]] - [[Naval Commander Class I]]
				- [[Theano Blackwood]] - [[Naval Commander Class I]]
			- Forces:
				- 20 [[Pure Demigod]]s from various gods (Commanders included)
				- ~10,000,000,000 Lives
		- Vanguard Fleet Alpha: [[UOE]]
			- Battleships:
					I. [[Corvette]] - ~30,000 [[Vanguard Pattern]]
					II. [[Light Frigate]] - ~8,000 [[Mastodon Pattern]]
					III. [[Frigate]] - ~200 [[Hammerhead Pattern]]
					VI. [[Cruiser]] - 7 [[Ultra-Heavy Icarus Pattern]]
					VII. [[Dreadnought]] - 2 [[Perseus Pattern]]
					VIII. [[UOE Aphrodite's Grace]]
			- Commanders:
				- [[Orion Blackwood]] - [[Naval Commander Class II]]
				- [[Aria Sterling]] - [[Naval Commander Class III]]
			- Forces:
				- Her grand Majesty, the forever [[Divine Being 'Great Love']], enchantress of infinity, and [[Alternate Divine Being 'Heart of Calamity']]: [[Aphrodite]]
				- [[Stephanie Callidora]] - Helion Bulwark of Aphrodite
					- UOE Sovereign's Glory
				- [[Michael Black]] - Selenide Bulwark of Aphrodite
					- UOE Flame of Ambition
				- 87 [[Second-Born Demigod]]s
				- 124 [[Neo-demigod]]s
				- ~200,000,000 Lives
- 16214.1.1
	- Capitulating on the planned new years celebrations, [[UOE]] forces attempted to breach the [[Yamamoto Chokepoint Relay]], and were partially successful. Half of the corvette fleet and light frigate fleet made it through, along with [[UOE Aphrodite's Grace]] and its escorting cruisers, albeit with dead engines, due to its excessive size and incompatibility with the relatively small relay.
	- Due to the lack proper naval formations and fleet compositions, both sides were dangerously lacking in certain armaments crucial to keep a conventional fleet effective. 
		- On the side of [[The Princes]], [[Solon Themis]] had ordered the relocation of the Icarus corvettes and Mastodon light frigates in order to facilitate colonization of [[Voss Primaris]] and [[Voss Secundus]]. Lacking in critical [[Point-Defence]] and Scrumming ships, The defenders were forced to leverage their heavier ships' longer range weaponry, and either rely on their afterburners to stay out of range, or to trust their [[Warp Shielding]] to nullify ranged attacks.
		- On the side of the [[UOE]], The vanguard forces struggled with the corresponding long range weapons, as [[UOE Aphrodite's Grace]] only possessed defensive capabilities, and the lighter ships only possessed basic [[THMNCLR]] Missiles, [[Pile Bunker]] Rams, [[TRP]] bays, and [[Flak]].
		- An consideration must be made that the UOE commander's knew about this apparent weakness in fleet composition, but chose to send the fleet anyways before the enemy could "Fortify the that damn chokepoint properly" (Michael Black, 16213.12.3.7 | 2:42 AM)
	- Broadsides were fired immediately the moment enemy ships were predicted to hit [[Augur]] channels, and managed to take down a large amount of the initial unprepared Vanguard Pattern corvettes. The [[Peitho-Class Broadsides]] from the [[Jackson Pattern]] dreadnoughts shredding the initial wave of invaders.
	- A few minutes later, the second wave appeared, accompanied by a significant amount of light frigates. Again, they proved no match against the Jackson Pattern dreadnoughts that the [[Pure Demigod]]s had jealously hoarded from the rest of the imperial navy. But, by a pure stroke of luck, the debris of the previous corvettes and the new frigates allowed enough cover from the propagating shrapnel of the broadsides, allowing for the remaining corvettes to set up a shielding array in front of the Relay, and thus establishing a foothold in the system.
	- As the main invading fleet began slowly making their way through, they were interrupted again as the reinforcements came in. The defenders slowly established a perimeter approx. 0.5 AU from the sandwiched [[Glass Worlds]], which quickly became the only source of real cover for the invaders. Countless [[Icarus Spinal Arrays]] among other weaponry were aimed at any exits among the debris, and engineers quickly began working on creating orbital cannons on a moon later named [[Tears of Lysandra]] still orbiting the Glass Planet.
	- By this time, [[UOE Aphrodite's Grace]] had finished it's exit back into normal space, and with its hyper-sensitive augurs, could easily bathe the whole system with scans, which it immediately began doing. As expected, it had caught wind of the actions of the engineers on Tears of Lysandra, and quickly informed their allies that if that moon were to cross the narrow gap between the two Glass Worlds, its orbital emplacements could easily decimate the hunkered forces. Realizing they had less than 65 Gaian Hours to work with, the invaders were on borrowed time. 
- 16214.1.2
	- With time quickly running short, the invaders were running out of options. In a stroke of genius, Her Divine Majesty [[Divine Being 'Great Love']] absorbed the 7 Accompanying cruised into the hold on her ship, and using its overpowered [[Dematerialization Field]], cloaked the rest of the fleet and cut all noise. 
	- Having perceived no visible or augur-related fluctuations ever since the first encounter, the defenders grew skeptical, perhaps expecting that the fleet had retreated to lick its wounds and wait for reinforcements. Nonetheless, they decided to bide their time and to use the newly constructed moon base to verify their findings. For now, expect for the slow, elliptical orbit of the moon, nothing would move.
- 16214.1.5
	- When the moon base rounded the corner and aimed at the pulsing gate, the gunners were pleasantly surprised to see graveyard of ships, but no actual ships lying in wait. Upon reporting the information to the high admirals, they remained skeptical, and ordered the firing of multiple volley's into the general area just to make sure. Upon firing until the Hyperium buffers had run out, the attacks proved the common consensus. Nothing was in there. How dreadfully wrong they were.
	- Unbeknownst to the defenders, The Heart of Calamity had pulled an favor from the hands of Lady [[Fortuna]] herself, and a high-level one too. Due to this, the Icarus shots had all "miraculously" missed the clustered frigates, and even the hulking 35 kilometer flagship tucked behind a shattered continent.
- 16214.1.6
	- Now confident that the invaders had left, [[Lysandra Voss]] and [[Solon Themis]] relaxed. Dismissing the majority of the fleet back to its original locations, they instead requested for large amounts of construction ships to be sent from the budding colonies to fully transform the area around the [[Yamamoto Chokepoint Relay]] into a kill zone.
	- Now painfully aware of their lack of defenses, many of the construction ships were recalled from other sections of the system to shore up the blind spots from the moon base's orbit. With a significant lack of [[Eurobium]] for its [[Warp Shielding]] capabilities, the decision was made to scrap the debris from the Vanguard and Mastodon shipwrecks (As those patterns, built for close combat, boasted strong void shields).
- 16214.3.2
	- The first moment anyone realized something was afoot was when an unknown supervisor, reported a few missing ships along the western side of the valley between planets. Thinking it was simply interference from the debris, the overseer filed a report and sent some more reconnaissance drones to check on the situation. 
	- Keeping a close eye on any developments, the drones approached the location of the lost ships. To the overseer's horror, the construction ships had all been decimated, destroyed by an unknown cause. Efforts were made to retrieve the Black Boxes, but not a single one could be found. 
	- A passing dreadnought, noticing the disturbance, quickly drifted over. With a quick augur-transmission, it was informed of the situation. Perhaps thinking it was a few surviving cloaked ships, [[UOE Edge of Anaklusmos]] confidently rushed to the site. It's destruction would mark the first blood for the attackers.
	- *Anaklusmos* had inadvertedly drifted past the holds of *Aphrodite's Grace*, unknowingly drifting past the primed broadsides of the cruiser's nestled inside. It is unknown which commander had ordered the first shot, but once the uplinked ships had received the commands, the [[Nested Missile batteries]] all fired simultaneously, unleashing thousands of IPBMs. Without time to put up its deflectors, and engines at dead slow, even the [[Jackson Pattern]] dreadnought, praised for its legendary durability, was brought to its heel in mere seconds. Its last transmission would later resurface from its black box:
	  "This land, not of mine, I shall feed the thirsty earth with my flesh. And everything that walks upon this land shall will spell your death"
	- No longer needing to keep up the [[Dematerialization Field]] for any longer, the fleet uncloaked and rushed out of its hiding spot, catching the defenders off-guard. Voss, realizing that the situation had grown increasingly out of control, and with a rapidly diminishing pool of resources, decisively ordered the deliberate scuttling of 300 [[AnnChase Pattern]] cruisers and their [[Hyperium]] reserves. Although unable to verify numbers at the time, it was later found out that every corvette and frigate was destroyed, and the cruisers, along with [[UOE Aphrodite's Grace]], had narrowly escaped through the [[TBN Relay]] while the Hyperium explosions covered sightlines, although with crippled shields and engines, rendering them near useless for the rest of the war. 
- 16214.3.7
	- Although a victory in the strategic sense, as the loss of 300 high-end ships would later seriously hinder combat maneuvers in the future for [[The Princes]], the near loss shifted public support, and foreign forces slowly began to move. 
	- key corporations would later include:
		- [[Institute Academy]]
		- [[Akvavit Mercenary Liaison Organization]]
		- [[Aldra Mercenary Liaison Organization]]
		- [[HadriCorp]]
			- [[Hadrian Tachyonics]]
- 16214.11.2
	- Perhaps due to the combat fluctuations, the bordered [[Japanese Pantheon]], now simply  known as the [[Dynasty]] began reconstruction of their respective stolen [[TBN Relay]], taken during [[The Great Expansion]]. [[Kagura Kuroyami]] was lead engineer, her work no doubt accelerating reconstruction efforts into a matter of months instead of decades
- 16214.11.4
	- Meanwhile, the [[UOE]] forces had finished construction of counter-breakthrough defenses, while [[UOE Aphrodite's Grace]] had been retired to a nearby system for higher-quality repairs
	- On the other side, The princes had finished construction of the 3 [[Dyson Sphere]]s, bringing in unparalleled power output, and reducing some planets into ice worlds, which were repurposed for cryogenic storage of materials
- 16215.12.1
	- On the Eve of December, 
- 16215
- 16215
- 16216
- 16216
	- With the situation increasingly desperate, [[The Princes]] were looking for more ways to escape their sticky situation. Going north was out of the question. The [[TBN Relay]] led into the cold embrace of the Void, subject to the whims IIIIIIIIIII and III IIIIIIIII, but the one that laid west held hope. Even though Shinto-Greco relations had broke down after [[The War of Heavens]] and near-wipeout by the hands of Blessed King [[Percy Jackson]], there was chance that they could offer support for rebels of the UOE such as them.
- 16216
- 16219
- 16219
- 16220
- 16220
- 16220
- 16220