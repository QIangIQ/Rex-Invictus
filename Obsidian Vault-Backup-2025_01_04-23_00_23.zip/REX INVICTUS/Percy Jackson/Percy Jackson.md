Part of the [[Greek Pantheon]]
Percy Jackson was a [[Demigod]] born on August 18th, to [[Poseidon]] and [[Sally Jackson]]. He was named after the famous Greek hero [[Perseus (Hero)]].

When Percy was still an infant, his father Poseidon left. To protect him and his mother from [[Zeus]] who would have been angered to discover that his brother broke the [[Oath (ambiguous)]]; a pact made by Zeus, Poseidon, and [[Hades]], to avoid having any more demigod children. 

Sometime while Percy was a toddler, Sally married [[Gabe Ugliano]] and hoped his horrible smell would mask her son's smell from the [[Monsters (Greek)]] that would hunt him down. 

Percy is a troubled 12-year-old boy who has been expelled from every school he has ever attended. He only has one friend there, [[Grover Underwood]], a [[Satyr]] in disguise sent to get Percy to [[Camp Half-Blood]] quickly.

Mrs. Dodds turns into the [[Fury]], and attacks him. Mr. Brunner (actually the [[Centaur]] [[Chiron]]), another one of Percy's teachers comes in and throws Percy a pen (actually [[Riptide]]). 

Percy grows extremely suspicious as the [[Fates]] snip the string

 He was cared for in the infirmary by [[Annabeth Chase]] starting their friendship, waking up three days later. He learned that he was at Camp Half-Blood, a place where demigods like him were trained to survive against [[Monsters (Greek)]].

The director of the camp was the Greek wine god, [[Dionysus]]. Shown around camp by Annabeth, his new friend and head counselor of the [[Athena's Cabin]]. Temporarily resided in the [[Hermes' Cabin]],

Percy encountered [[Clarisse]], counselor of the [[Ares' Cabin]]. After CTF, a [[Hellhound]] summoned from the [[Fields of Punishment]], came out of the forest and attacked him. Percy was nearly killed but Chiron managed to shoot the hellhound, killing it.

Percy was offered a quest to retrieve Zeus's [[Master Bolt]] by Chiron. Percy accepts the quest and consults the camp's [[Oracle of Delphi]] and getting a prophecy. 

[[Ares]] offers them a mode of transportation west, they arrive in Las Vegas, where they stumble upon the [[Lotus Hotel and Casino]]. 

[[Kronos]] stops an infuriated Ares from killing Percy. Ares vanishes in his divine form, leaving the bolt and [[Helm of Darkness]] behind. 

On the way to camp, in the Gray Sisters' Taxi, which is a taxi business run by the [[Gray Sisters]], Percy learns the for the [[Golden Fleece]].Percy arrives at camp to find the camp under attack by [[Colchis Bulls]] 

He learns [[Thalia's Pine Tree]] is poisoned. [[Clarisse]], the daughter of Ares and Percy's enemy, is assigned a quest to go to the [[Sea of Monsters]]

Dionysus and [[Tantalus]], refused participation.

[[Thalia Grace]], Percy, and [[Annabeth Chase]] heard that siblings, [[Bianca di Angelo]] and [[Nico di Angelo]], had been found in a middle school. [[Dr. Thorn]], a [[Manticore]]

Then, [[Artemis]] and her [[Hunters of Artemis]] appear and Annabeth falls from a cliff as she had climbed on Dr. Thorn with her knife before the Hunters shot him down with their arrows. 

Artemis then sends her Hunters to Camp Half-Blood with [[Apollo]], her twin brother. When he got to camp he went to see the [[Oracle of Delphi]]

Thalia then runs up to Percy, asking him what he was thinking as when she got to the flag's spot, it was gone. She then shocks him with [[Electrokinesis]]

As they drive up the mountain towards the [[Garden of the Hesperides]], the car explodes due to a lightning bolt that struck it forcing them to complete the rest of the climb on foot. When they reach the Garden, Percy and Thalia find out that Zoë is a [[Hesperide]] after meeting her sisters, and she is poisoned by the dragon, [[Ladon]] but manages to distract it, clearing a path for the others. Then they continue on to the place where [[Atlas]] held up the sky

Percy rescued Annabeth and they manage to escape the mountain, thanks in part to [[Frederick Chase]] shooting the monsters with his plane using [[Celestial Bronze]] bullets. He, along with Annabeth and Thalia, then go to Mount Olympus on Blackjack and his friends, [[Guido]] and [[Porkpie]]. While flying, Percy and Thalia believe that Luke is dead as Thalia had thrown him down a deep chasm, but Annabeth believes otherwise. Percy becomes slightly jealous of the affection Annabeth was showing for Luke, which surprises him because it has never really bothered him before now.

When they arrive in Mount Olympus, the [[Winter solstice]] meeting had already begun, and they begged Zeus to believe that [[Kronos]] was indeed rising. 

[[Quintus]] (actually [[Daedalus]] in disguise), the new swordsman, is accompanied by [[Mrs. O'Leary]], a hellhound that develops a soft spot for Percy.

During a game that Quintus made up, Annabeth and Percy go through the rocks of [[Zeus's Fist]]  and fall in a dark cavern which they later find out is an entrance to the Labyrinth. Annabeth is offered the quest she has been waiting for since age 7: She must enter the [Labyrinth](https://riordan.fandom.com/wiki/Labyrinth "Labyrinth"), find [[Daedalus]], and get [[Ariadne's String]] before their arch enemy, [[Luke Castellan]] does. 

After they escape from the Sphinx, they find an exit that takes them to [[Hephaestus]], who has them travel to one of his forges to find out who has been using them, and in return, he will help them find Daedalus. Percy gets lost in the inner depths of [[Mount Saint Helens]] while battling fierce [[Telekhines]]. In desperation, he unleashes an incredible amount of power and blasts out of Mt. Saint Helens, creating an explosion that damages the volcano, stirs [[Typhon]] in his sleep, and causes the evacuation of hundreds of thousands of people living around Mt. Saint Helens. He ends up falling into [[Ogygia]], where he meets [[Calypso]]

Together, they all find [[Pan]], the god of the wild, who tells them he is dying. 

Poseidon is fighting [[Oceanus]] and his army, aging rapidly due to the state of his kingdom being destroyed. 

Percy to bathe in the [[Styx]] to become invulnerable like the hero [[Achilles]]. 

Percy Jackson is being attacked by the [[Gorgons]], [[Stheno]], and [[Euryale]], intent on avenging their sister, [[Medusa]]'s, death. 

He had woken up at the [[Wolf House]], and met [[Lupa]]

He meets up with [[Juno]], The waters of the river seemed to have also washed away his [[Curse of Achilles]], as after the waters receded, Percy felt like he had been in an acid bath and he felt vulnerable. Just then, Percy is met by many demigod children, including [[Frank Zhang]], [[Hazel Levesque]], and [[Reyna Avila Ramírez-Arellano]]. June introduces him as a son of [[Neptune]] and Reyna seems to know Percy somehow when she hears his name which confuses him. June then shows her true form as [[Juno]] and the campers bow in respect

They then move to Portland where they encounter [[Ella]] and the wicked king and seer, [[Phineas]] who also appears to have knowledge of the past, present, and future although he is blind.

Frank was able to free [Thanatos](https://riordan.fandom.com/wiki/Thanatos "Thanatos") by burning a piece of wood which contained Frank's life. 

Jason, Annabeth, Percy, Hazel, Frank, and Piper escape to their ship with the Romans hot on their tail. Annabeth, assigned a mission from her mother Athena to recover the _[Athena Parthenos](https://riordan.fandom.com/wiki/Athena_Parthenos "Athena Parthenos")_, must go her own way and thus Percy becomes extremely worried. 

After he battled with the twin giants [Otis](https://riordan.fandom.com/wiki/Otis_(Giant) "Otis (Giant)") and [Ephialtes](https://riordan.fandom.com/wiki/Ephialtes "Ephialtes") (succeeding by working together with Jason and [[Bacchus]]

Guarding the Athena Parthenos was [Arachne](https://riordan.fandom.com/wiki/Arachne "Arachne"), who Annabeth tricked into trapping herself. As Arachne falls into the abyss of [Tartarus](https://riordan.fandom.com/wiki/Tartarus_(place) "Tartarus (place)") 

Annabeth gets dragged towards to Tartarus, and Percy holds onto her.

The river was the river [Cocytus](https://riordan.fandom.com/wiki/River_Cocytus "River Cocytus")

Percy and Annabeth drink from the flaming river, the river [Phlegethon](https://riordan.fandom.com/wiki/River_Phlegethon "River Phlegethon"), which allows monsters to endure the punishments in Tartarus.

Two days later, Percy met the seven for breakfast to discuss subduing [[Nike]]

After Nike split into Nike and [[Victoria]], The [[Nikai]] forced them into the arena

He insisted that Annabeth and Piper cannot face [[Mimas]] and the [[Makhai]]

They were suddenly greeted by [[Kymopoleia]]

Suddenly, [[Polybotes]] recognized Percy and vowed to crush him once and for all.

He said when he was choking on the poison, he thought about [[Akhlys]] and when he poisoned her, how it felt good

one snake man introduced himself as a [[Geminus]]

He faced [[Thoon]] but couldn't realize that his nose was bleeding. Piper tried to warn him, but his blood spilled and Gaea woke. But suddenly, all of the [[Olympians]] and some other gods arrived due to the [[Athena Parthenos]] being returned, so Percy fought alongside Poseidon to defeat [Otis](https://riordan.fandom.com/wiki/Otis_(Giant) "Otis (Giant)") and [[Ephialtes]]. 

A [[Giant Crocodile]] has been terrorizing Long Island, along with other magical disturbances in the area. Percy approaches and stabs the beast in the rear with [Riptide](https://riordan.fandom.com/wiki/Riptide "Riptide"). The crocodile proceeds to spit out [[Carter Kane]]

Percy can clearly see his wand and [khopesh]

The two form a truce so that they can go after the crocodile, as it has been terrorizing Long Island

They take a ferry to Governor's Island where a freak hurricane has caused all the mortals to evacuate. While they are trapped on the island surrounded by snakes, they attempt to contact [Carter Kane]and [Sadie Kane] but fail. Annabeth and Percy decide to face [Setne]. Setne reveals that he was watching Annabeth and Sadie when they were battling [Serapis]

Percy and Annabeth decide to not tell Camp Half-Blood, at least not yet. The four determine that they will remain in contact.

Percy and Annabeth were in Boston to help train [[Magnus Chase]] and his friend, [[Alex Fierro]]. When [[Sumarbrander]] started talking, Magnus introduced him to Percy and Annabeth. Percy was nervous when the sword flew to him, and learned that [[Riptide]] was actually a girl. Percy uncapped the pen and made it a sword so Riptide and Jack could bond with each other. Percy was shocked that she was a girl

Contracted with:
1. [[Artemis]]
2. [[Athena]]

friends with:
1. [[Thalia Grace]]
2. [[Jason Grace]]


Abilities:
- [[Hydro-Telekinesis]]
- [[Property Manipulation]]
    - [[Viscosity Manipulation]]
- [[State Manipulation]]
- [[Water Detection]]
- [[Hydrokinetic Regeneration]]
- [[Blood Manipulation]]
- [[Superior Human Physiology]]