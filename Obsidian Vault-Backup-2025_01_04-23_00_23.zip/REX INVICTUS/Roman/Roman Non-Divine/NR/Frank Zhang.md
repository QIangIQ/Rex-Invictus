Part of the [[Roman Pantheon]]
Part of the [[Greek Pantheon]]
Son of [[Mars]]
[[Legacy]] of [[Poseidon]]
Relationship with [[Hazel Levesque]]

[[Fire Generation]]
[[Combustion Inducement]]
[[Inflammation]]
[[Self Combustion]]

