Part of the [[Roman Pantheon]]
Daughter of [[Pluto]], Alternate form of [[Hades]]
Member of [[New Rome]]
Ability to summon gems and commands [[Arion]]