Part of the [[Roman Pantheon]]
Part of the [[Greek Pantheon]]
[[Pegasus]] of [[Reyna Avila Ramírez-Arellano]]