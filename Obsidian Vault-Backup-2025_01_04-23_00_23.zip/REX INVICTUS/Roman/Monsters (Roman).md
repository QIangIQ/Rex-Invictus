Similar to [[Monsters (Greek)]], these creatures fall under the [[Monster]] category
Also reform in [[Tartarus (Realm)]]