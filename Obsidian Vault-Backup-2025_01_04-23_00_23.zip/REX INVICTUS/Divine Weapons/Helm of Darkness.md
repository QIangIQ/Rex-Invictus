[[Greek Pantheon]]
[[Divine Weapons]], Signature weapon of [[Hades]]
Grants near total invisibility, except for negative space
