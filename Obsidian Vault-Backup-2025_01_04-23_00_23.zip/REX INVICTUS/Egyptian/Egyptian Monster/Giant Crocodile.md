Part of the [[Egyptian Pantheon]]
Consumed [[Carter Kane]]
Defeated by [[Percy Jackson]]
[[Monsters (Egyptian)]]
