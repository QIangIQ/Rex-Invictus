[[Roman Pantheon]]
Residence of [[Lupa]]
Resting place for both [[Hunters of Artemis]] and [[Hounds of Artemis]]