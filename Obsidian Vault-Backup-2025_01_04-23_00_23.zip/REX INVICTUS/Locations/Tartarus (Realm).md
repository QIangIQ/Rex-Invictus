[[Greek Pantheon]]
The body of [[Tartarus (Primordial)]]
Place where [[Monsters (Greek)]], [[REX INVICTUS/Definitions/Titan]]s, and [[Primordial]]s reside and reform
where the 5 rivers:
The River [[Lethe]]
The River [[Cocytus]]
The River [[Acheron]]
The River [[Phlegethon]]
The River [[Styx]]
flow and combine into the [[Heart of Tartarus]], at the center