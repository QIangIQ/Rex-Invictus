Part of the [[Greek Pantheon]]
in [[Camp Half-Blood]]
similar to [[Zeus]]' fist
entrance to [[Labyrinth]]