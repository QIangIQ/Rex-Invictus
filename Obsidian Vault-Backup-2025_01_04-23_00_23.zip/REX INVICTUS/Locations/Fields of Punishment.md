[[Greek Pantheon]]
Under dominion of [[Hades]]
Overseen by the [[Fury]]s
Holding pen for [[Hellhound]]s
Where the evil and cruel are punished