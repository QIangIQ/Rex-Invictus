Gods are emergent embodiments of physical or metaphysical qualities present within a universes. 
Their sentience arises from same latent pool of awareness as all other life. Manifesting as avatars that posses power and dominion over the  aspects of existence they embody
it is nearly impossible to kill a god, while their specific personalities or awareness can be expunged, the qualities they embody can rarely be destroyed. Thus a new avatar will always be reborn in time, unless seized by the being that destroyed  their previous divine representative, or an appointed heir. Their main source of fuel is the belief of its denizens, who also assist in shaping its ideals and ego.

Many forms of god exist in the current setting, the main players including:
- [[God (greek)]]
- [[God (norse]]
- [[God (japanese)]]
- [[God (roman)]]

