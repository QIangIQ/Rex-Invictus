[[Greek Pantheon]]
Given by the [[Styx]], provides invulnerability towards fatal damage
Persons of Interest:
[[Percy Jackson]]
[[Achilles]]
[[Luke Castellan]]