
- [[Heat Absorption]]
- [[Heat Immunity]]
- [[Self Combustion]]
- [[Fire Infusion]]
- [[Greek Fire Manipulation]]
- [[Energy Manipulation]]
- [[Superior Human Physiology]]
- [[Purification]]