Part of the [[Greek Pantheon]]
Reside on [[Olympus]], and all of its variants,
[[Olympus Primaris]]
[[Olympus Secundus]]
[[Olympus Tertiae]]