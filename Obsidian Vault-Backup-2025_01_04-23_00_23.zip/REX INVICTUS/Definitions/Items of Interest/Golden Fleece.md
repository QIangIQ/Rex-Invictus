Part of the [[Greek Pantheon]]
The fleece of the Golden-wooled of a ram, Chrysomallos . Who that rescued Phrixus and brought him to Colchis, where Phrixus then sacrificed it to [[Zeus]].

Retrieved by [[Clarisse]], [[Annabeth Chase]], [[Percy Jackson]], and [[Grover Underwood]]
Now sits in [[Camp Half-Blood]], guarded by [[Peleus]], under [[Thalia's Pine Tree]]