[[Demigod of Aphrodite]]
Daughter:
[[Stephanie Callidora]]