[[Spinal Weapons]]:
[[Broadside Weapons]]: