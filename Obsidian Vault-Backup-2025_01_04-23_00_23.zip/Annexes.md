Emergent Age
[[The Great Expansion]]
- Battle of Mining plant 23489-FRJ 
	- [[Annex 13287]]
Post [[War of Princes]]