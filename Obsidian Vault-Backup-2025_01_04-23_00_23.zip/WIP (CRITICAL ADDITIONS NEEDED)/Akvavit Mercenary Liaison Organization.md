Iniytally established during [[War of Princes]], gained fame due to the famous defense of [[Terra Secundus]]
the North sector [[MLO]] & [[PMC]] organization
Characterized by easy-to-hire services.
HQ located in the far north, but their reach spreads across the galaxy
Forces numbe