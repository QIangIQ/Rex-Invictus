Categorized between 000~999, megastructures that span the entire [[Karman Line]]
Serve as space elevators, local point-defense, long range plasma and kinetic weaponry, slingshots, and 