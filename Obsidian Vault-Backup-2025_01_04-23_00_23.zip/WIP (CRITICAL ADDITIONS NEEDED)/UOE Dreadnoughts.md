UOE Divine Crusader:
Pilot: [[Eleni Theodosia]] - [Demigod of Zeus]
UOE Fanatical Zealot:
Pilot: Nikos Agathon - [Demigod of Ares]
UOE Radiant Avenger:
Pilot: Kallisto Evadne - [Demigod of Athena]
UOE Eternal Devotion:
Pilot: [[Stephanos Pyrrhus]] - [Demigod of Poseidon]
UOE Glorious Conquest:
Pilot: A lexandros Leonidas - [Demigod of Zeus]
UOE Fanatic's Fury:
Pilot: Andromeda Kallisto - [Demigod of Apollo]
UOE Celestial Martyr:
Pilot: [[Damocles Euphemios]] - [Demigod of Dionysus]
UOE Zealous Triumph:
Pilot: Kyriakos Theodosios - [Demigod of Demeter]
UOE Radiant Crusade:
Pilot: [[Melina Callisto]] - [Demigod of Demeter (Huntress)]
UOE Eternal Glory:
Pilot: 
UOE Vengeful Wrath:
Pilot: Nikos Phobos - [Demigod of Hades]
UOE Glorious Retribution:
Pilot: Eleni Xenia - [Demigod of Hestia]
UOE Eternal Fury:
Pilot: Kleon Aristides - [Demigod of Hermes]
UOE Blade's Edge:
Pilot: Kyriakos Alexandros - [Demigod of Elektra]
UOE Gods' Lance:
Pilot: Alexandros Aetios - [Demigod of Apollo]
UOE Celestial Fury:
Pilot: [[Andromeda Kallisto]] - [Demigod of Athena]
UOE Solar Flare:
Pilot: Helios Theokritos - [Demigod of Apollo]
UOE Ironclad Sentinel:
Pilot: Theophanes Leonidas - [Demigod of Athena]
UOE Voidbringer:
Pilot: Iason Dimitrios - [Demigod of Nikos]
UOE Radiant Dawn:
Pilot: [[Elektra Callidora]] - [[Demigod of Aphrodite]]
UOE Divine Blade
Pilot: 
UOE Fury's Embrace
UOE Celestial Guardian
UOE Shadow Sentinel
UOE Wrath of Oylmpus
UOE Eternal Vigilance
UOE Phoenix's Ascension
UOE Starfire Crusader
UOE Radiant Eclipse
UOE Thunderous Reckoning
UOE Ironclad Bastion
UOE Wrathful Tempest
UOE Astral Dominion
UOE Warbringer Fury
UOE Solaris Retribution
UOE Nova Fury
UOE Sovereign's Glory
[[Stephanie Callidora]] - Helion Bulwark of Aphrodite
UOE Astral Conquest
UOE Voidstar Sentinel
UOE Thunderous Oath

UOE Flame of Ambition
[[Michael Black]] - Selenide Bulwark of Aphrodite
