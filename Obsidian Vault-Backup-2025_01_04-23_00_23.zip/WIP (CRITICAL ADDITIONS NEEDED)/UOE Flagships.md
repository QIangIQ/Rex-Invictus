

UOE Olympian Fury
- Mobile Fortress
- Macro Cannon
UOE Athena's Shield
- Oversized Void shields
UOE Zeus' Thunderbolt
- Flagship of Oylmpus
- Spearhead of Oylmpus
[[UOE Aphrodite's Grace]]
- Support Ship, Hospital
UOE Hades' Shadow
UOE Poseidon's Trident
UOE Artemis' Arrow
UOE Hermes' Messenger
- Mobility 
UOE Hera's Justice
UOE Dionysus' Revelry
UOE Apollo's Sunburst
UOE Demeter's Harvest
- Large (400km)? Storage and harvesting ship
UOE Ares' Battlecry
UOE Hephaestus' Forge
- Fabricator Ship
UOE Hestia's Hearth
- Support Ship, Hospital
UOE Nike's Triumph
UOE Pan's Wildfire
