Arise, ye who do not fear death
Arise, ones brave enough to take up thy weapons
Pray for the deaths of thy enemies
Warriors, gather to this banner
To take back our pride
from the beasts called Gods!
The eternal blight of man!
Follow me through the darkness!
In the name of man!
Let your bodies tremble,
Let your bodies tear!
Reach high and praise me, for I am the one who brings salvation!
The enemies have their lives forfeit.
Crossing blades with the embodiment of wrath,
For I. am. Destruction.

—----

This land is not of mine, and I shall feed the thirsty earth with my flesh. And everything that walks upon this land shall be your ally.

—-------

Humans possess nature, it follows that weapons possess natures too. What is innate in human nature is Good and Evil. Be it evil, be it good, it is what was bestowed by the Creator. From such simple beginnings, we have gradually evolved into thousands of completely different human depositions. And what’s innate in a blade is- 

He swung.

To kill. To kill for war, to kill for one’s revenge, to kill for resources, and-

The mannequin fell.

To kill scum of the world. The traitors, the unbelievers, the heretics.

He sheathed his sword.

As such, it has evolved to the infinitely countless styles of combat. Your weapon represents you as you are, and you are a messenger of your weapon.
–
Mercy to the guilty is cruelty to the innocent - Adam Smith
-
coget omnes ante thronum
-
quidquid latet, apparebit
