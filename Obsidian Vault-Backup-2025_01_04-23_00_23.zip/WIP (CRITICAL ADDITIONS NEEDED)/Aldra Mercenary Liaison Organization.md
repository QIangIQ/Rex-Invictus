Highly-Exclusive mercenary services and logistics department. Exclusively under [[UOE]]'s thumb
Holds absolute power in West & South