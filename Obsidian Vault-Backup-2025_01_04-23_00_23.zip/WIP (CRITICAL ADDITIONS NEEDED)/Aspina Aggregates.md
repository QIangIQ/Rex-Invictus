Minor [[Merchant Guild]]/[[Smugglers Guild]]. Easiest Source of [[Hyperium]], [[Eurobium]], [[Teshlack]], and [[Projinite]] outside of the [[UOE]]
