Specialized in the production of [[Titan (Mech)]] leg, arm, and core parts
Subsidiary of [[Beleth Mechanized Division]]