Mining Corporation. Specialized in the harvesting of asteroid belts, ,moons, and blank planets.
Recently involved with a scandal with the [[Astralnet Conglomerate]]