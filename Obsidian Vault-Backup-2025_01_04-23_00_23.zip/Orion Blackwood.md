[[Second-Born Demigod]]
Naval Commander Class II