[[Greek Pantheon]]
[[God]] of Peaceful death