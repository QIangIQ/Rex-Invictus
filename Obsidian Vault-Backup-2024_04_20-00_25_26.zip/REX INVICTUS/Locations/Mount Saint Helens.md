[[Greek Pantheon]]
Location of a [[Forge of Hephaestus]]