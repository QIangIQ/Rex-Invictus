[[Greek Pantheon]]
Designed by [[Daedalus]], holds [[Monsters (Greek)]]
acts as a transportation hub, connects to [[Olympus]] and [[Camp Half-Blood]], among others