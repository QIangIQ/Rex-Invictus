Member of the [[Egyptian Pantheon]]
Brother of [[Sadie Kane]]
Pharaoh of the [[House of Life]]
Relationship with [[Zia Rashid]]