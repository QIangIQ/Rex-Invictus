[[Egyptian Pantheon]]
Monsters that fall under the Egyptian Pantheon