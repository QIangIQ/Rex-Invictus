Member of the [[Norse Pantheon]]
[[Demigod]] son of [[Loki]]