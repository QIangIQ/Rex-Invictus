[[Greek Pantheon]]
[[Divine Weapons]] of [[Athena]]
Matches set of 2, with [[Ageis]]
