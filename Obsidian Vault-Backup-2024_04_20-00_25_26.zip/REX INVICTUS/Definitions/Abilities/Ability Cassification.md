[[Pyrokinesis]]
[[Geoknesis]]
[[Hydroknesis]]
[[Electrokinesis]]
