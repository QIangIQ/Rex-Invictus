Part of the [[Greek Pantheon]]
Prophecy given by the [[Oracle of Delphi]]
Involves:
[[Thalia Grace]]
[[Percy Jackson]]
[[Luke Castellan]]
[[Nico di Angelo]]
[[Rachel]]
[[Kronos]]
[[Zeus]]
[[Poseidon]]
[[Hades]]
[[Annabeth Chase]]

