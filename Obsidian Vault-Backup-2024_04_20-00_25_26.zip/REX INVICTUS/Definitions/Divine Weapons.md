Signature weapon of a [[God]] or similarly Divine Deity, Holds [[Divine Power]]

