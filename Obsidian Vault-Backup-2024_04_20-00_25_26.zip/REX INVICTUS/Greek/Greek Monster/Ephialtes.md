Part of the [[Greek Pantheon]]
[[Giant (Greek)]]
Born to oppose [[Dionysus]]
