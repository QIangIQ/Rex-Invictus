Part of the [[Greek Pantheon]]
Monsters that originate from the greek pantheon
Reform in [[Tartarus (Realm)]]
Generally descendants of:
[[Echidna]]
[[Tartarus (Primordial)]]
[[Nyx]]
[[Typhon]]
