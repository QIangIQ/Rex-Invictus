Part of the [[Greek Pantheon]]
River of Sadness, ruled by [[Hades]]