Part of the [[Greek Pantheon]]
General of [[Atlantis]]
Servant of [[Poseidon]]
