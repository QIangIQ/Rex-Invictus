Wife of [[Poseidon]]
Mother of [[Triton]]
Can command [[Delphin]] and [[Atlantis]] as a Regent/Proxy