Part of the [[Greek Pantheon]]
Main river [[Naiad]]
Part of the court of [[Poseidon]]