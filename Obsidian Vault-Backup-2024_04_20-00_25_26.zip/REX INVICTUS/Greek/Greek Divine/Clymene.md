[[Greek Pantheon]]
Part of the 3000 original [[Nymphs]]
Daughter of [[Oceanus]] and [[Tethys]]
