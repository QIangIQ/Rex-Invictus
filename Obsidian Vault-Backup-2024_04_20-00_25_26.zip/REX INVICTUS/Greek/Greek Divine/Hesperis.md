[[Greek Pantheon]]
Minor sea [[God]]ess
Once had the [[Hesperide]]s with [[Atlas]]