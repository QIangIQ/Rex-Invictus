Part of the [[Greek Pantheon]]
Forged by [[Hephaestus]], most are used in farms used by [[Demeter]], but rouge ones have aligned with [[Tartarus (Primordial)]]
[[Monsters (Greek)]]
