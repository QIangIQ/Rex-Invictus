Part of the [[Greek Pantheon]]
Legacy of the [[Japanese Pantheon]]
Granddaughter of [[Raijin]]
