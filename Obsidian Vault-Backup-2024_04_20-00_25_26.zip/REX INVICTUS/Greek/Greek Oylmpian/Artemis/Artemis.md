[[Divine Being 'Providence of Archers']]
[[Percy Jackson]]
[[God]]
Sister of [[Athena]]
Sister of [[Ares]]
Sister of [[Dionysus]]

Head of [[Artemis-Aligned Factions]]
Leader of [[Hunters of Artemis]]

Holds Epithets:
[[Peitho]]
[[Agrotera]]
[[Chitone]]
[[Game’lii]]
[[Hege’mone]]
[[Limenia & Limenitês & Limenitis & Limenodkopos]]
[[Parthenia]]
[[Phoebe & Orthia]]
[[Phosphorus]]
[[Upis & Melissa & Locheia & Genetyllis]]
[[Heurippe]]

