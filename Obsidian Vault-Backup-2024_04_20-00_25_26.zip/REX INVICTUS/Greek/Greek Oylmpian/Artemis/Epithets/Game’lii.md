protecting and presiding over marriage
